items = [
    {'form': 'square', 'letter': 'E', 'color': 'blue', 'border': False},
    {'form': 'circle', 'letter': 'A', 'color': 'red', 'border': True},
    {'form': 'circle', 'letter': 'B', 'color': 'green', 'border': False},
    {'form': 'diamond', 'letter': 'E', 'color': 'red', 'border': True},
    
    {'form': 'diamond', 'letter': 'E', 'color': 'red', 'border': True},
    {'form': 'diamond', 'letter': 'C', 'color': 'blue', 'border': False},
    {'form': 'square', 'letter': 'A', 'color': 'green', 'border': False},
    {'form': 'diamond', 'letter': 'D', 'color': 'green', 'border': True},
    
    {'form': 'star', 'letter': 'C', 'color': 'silver', 'border': True},
    {'form': 'square', 'letter': 'C', 'color': 'silver', 'border': False},
    {'form': 'circle', 'letter': 'B', 'color': 'green', 'border': False},
    {'form': 'circle', 'letter': 'A', 'color': 'red', 'border': True},
    
    {'form': 'square', 'letter': 'A', 'color': 'green', 'border': False},
    {'form': 'circle', 'letter': 'D', 'color': 'green', 'border': True},
    {'form': 'star', 'letter': 'B', 'color': 'blue', 'border': True},
    {'form': 'circle', 'letter': 'B', 'color': 'blue', 'border': True},
    
    {'form': 'square', 'letter': 'E', 'color': 'blue', 'border': False},
    {'form': 'diamond', 'letter': 'E', 'color': 'red', 'border': True},
    {'form': 'star', 'letter': 'B', 'color': 'blue', 'border': True},
    {'form': 'square', 'letter': 'C', 'color': 'purple', 'border': False},
    {'form': 'square', 'letter': 'C', 'color': 'silver', 'border': False},
]